package vo;

import java.util.List;

public class DataContent {

    private List<EdgeInfo> changed_edges;

    public List<EdgeInfo> getChanged_edges() {
        return changed_edges;
    }

    public void setChanged_edges(List<EdgeInfo> changed_edges) {
        this.changed_edges = changed_edges;
    }
}
