package vo;

public class Report {

    private ReportContent report;

    public ReportContent getReport() {
        return report;
    }

    public void setReport(ReportContent report) {
        this.report = report;
    }
}
