package vo;

public class ReportContent {

    private StatisticsContent statistics;
    private DataContent data;

    public StatisticsContent getStatistics() {
        return statistics;
    }

    public void setStatistics(StatisticsContent statistics) {
        this.statistics = statistics;
    }

    public DataContent getData() {
        return data;
    }

    public void setData(DataContent data) {
        this.data = data;
    }
}
