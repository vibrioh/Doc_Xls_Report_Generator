package vo;

public class LabelCount {

    private String label;
    private int count;
    private int count_changed;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getCount_changed() {
        return count_changed;
    }

    public void setCount_changed(int count_changed) {
        this.count_changed = count_changed;
    }
}
